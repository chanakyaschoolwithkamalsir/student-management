import json
import os
import django
from django.http import JsonResponse
from django.shortcuts import render, redirect
import pandas as pd
from .models import AboutPage, ContactPage, Student, Notice, Teacher, TestData,\
                    ChapterMaster, StudentTestResults
from django.views.decorators.csrf import csrf_protect
from django.db import connection
from .forms import StudentTestResultsForm  
from reportlab.lib.pagesizes import letter, landscape
from reportlab.pdfgen import canvas 
from django.http import HttpResponse
from django.http import FileResponse
# logo_path = 'static/kamal sir logo cdr.png'

from fpdf import FPDF
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Image
import io
import matplotlib.pyplot as plt
import seaborn as sns


class PDF(FPDF):
    def header(self):
        # Replace this with the path to your logo image
        logo_path = 'static/kamal sir logo cdr.png'
        self.set_font('Arial', 'B', 12)
        self.set_text_color(0, 0, 0)
        
        # Center-align the logo
        logo_width = 120  # Adjust the width as needed
        self.image(logo_path, self.w / 2 - logo_width / 2, 10, logo_width)
        self.ln(70)

    def chapter_title(self, student):
        # Student info styling
        self.set_font('Helvetica', 'B', 14)
        self.set_text_color(30, 144, 255)  # Blue color
        self.cell(0, 10, f'Student: {student["full_name"]}   |   Standard: {student["standard"]}th {student["medium"]}', 0, 1, 'C')
        self.ln(10)
        self.set_font('Arial', '', 12)

def generate_pdf_report(request, id):
    # Replace this with your database query or data retrieval logic
    query = f'''
            select str.id, student_id, test_id, td.total_marks, obtained, full_name, td.standard, td.medium,
            td.subject, td.test_date
            from sms_schema.student_test_results str
            left join sms_schema.main_student ms on ms.id=str.student_id
            left join sms_schema.test_data td on td.id=str.test_id
            where student_id={id} ORDER BY str.id desc'''
    
    df = pd.read_sql_query(query, connection)  # Replace 'connection' with your actual database connection

    # Convert 'test_date' to datetime
    df['test_date'] = pd.to_datetime(df['test_date'])

    # Calculate the percentage of obtained marks for each subject
    df['percentage'] = (df['obtained'] / df['total_marks'] * 100).round(2)

    # List of unique subjects
    subjects = df['subject'].unique()

    # Create an in-memory PDF
    pdf = PDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()

    # Get student info
    student_info = df.iloc[0]
    pdf.chapter_title(student_info)

    # # Embed the logo image
    # logo_path = 'static/kamal sir logo cdr.png'
    # logo_width = 120
    # pdf.image(logo_path, pdf.w / 2 - logo_width / 2, 30, logo_width)
    # pdf.ln(70)

    # Create a stylish table for student records
    record_table = [
        ['Subject', 'Test Date', 'Total', 'Obtained', 'Percentage'],
    ]

    col_widths = [50, 50, 30, 30, 30]

    for _, student_row in df.iterrows():
        record_table.append([
            student_row['subject'],
            student_row['test_date'].strftime('%d %b, %Y'),
            student_row['total_marks'],
            student_row['obtained'],
            student_row['percentage']
        ])

    # Header styling
    pdf.set_fill_color(0, 123, 255)  # Blue background
    pdf.set_font('Arial', 'B', 12)
    pdf.set_text_color(255, 255, 255)  # White text color
    for header_item, width in zip(record_table[0], col_widths):
        pdf.cell(width, 10, header_item, border=1, fill=True, ln=0, align='C')
    pdf.ln()

    # Data styling
    pdf.set_fill_color(240, 240, 240)  # Light gray background
    pdf.set_font('Arial', '', 12)
    pdf.set_text_color(0, 0, 0)  # Black text color
    for row in record_table[1:]:
        for data_item, width in zip(row, col_widths):
            pdf.cell(width, 10, str(data_item), border=1, fill=True, ln=0, align='C')
        pdf.ln()

    pdf.ln(10)

    # Create a separate bar chart for each subject using seaborn
    for subject in subjects:
        subject_data = df[(df['subject'] == subject) & (df['full_name'] == student_row['full_name'])]
        num_test_dates = len(subject_data['test_date'])
        chart_width = max(6, min(12, num_test_dates * 0.8))  # Limit the chart width between 6 and 12 inches

        plt.figure(figsize=(chart_width, 6))  # Adjust height as needed
        sns.barplot(x='test_date', y='percentage', data=subject_data, palette='tab20')
        plt.title(f'{subject.capitalize()} Performance (%)')
        plt.xlabel('Test Date')
        plt.ylabel('Percentage of Obtained Marks')
        formatted_labels = [date.strftime('%d %b, %Y') for date in subject_data['test_date']]
        plt.xticks(rotation=45)  # Rotate x-axis labels
        plt.tight_layout()

        # Save the chart to a file
        chart_path = f'chart_{subject}.png'
        plt.savefig(chart_path, format='png')
        plt.close()

        # Embed the chart image into the PDF
        pdf.ln(10)
        pdf.image(chart_path, x=pdf.w / 2 - chart_width * 30 / 2, w=chart_width * 30)  # Adjust factor for fine-tuning

        # Delete the temporary chart file
        os.remove(chart_path)

    pdf_output = pdf.output(dest='S').encode('latin1')

    response = HttpResponse(pdf_output, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="test_report_{id}.pdf"'
    return response


def home(request):
    publicNotices = Notice.objects.filter(isPublic = True)
    data = {"public_notices": publicNotices}
    return render(request, 'home.html', data)

def about(request):
    about_text = AboutPage.objects.all()
    data = {"aboutDetails": about_text}
    return render(request, 'about.html', data)

def contact(request):
    contact_text = ContactPage.objects.all()
    data = {"contactDetails": contact_text}
    return render(request, 'contact.html', data)

def adminPanel(request):
    if 'admin_user' in request.session:
        all_students = Student.objects.all()
        all_teachers = Teacher.objects.all()
        data = {'students': all_students, 'teachers': all_teachers}
        return render(request, 'admin/admin_panel.html', data)
    else:
        return redirect('admin_login')


def adminLogin(request):
    if request.method == 'POST':
        admin_email = request.POST['email']
        admin_pwd = request.POST['pwd']

        if admin_email == "admin@gmail.com" and admin_pwd == "admin@123":
            request.session['admin_user'] = admin_email
            return redirect('admin_panel')
        else:
            return redirect('admin_login')

    return render(request, 'admin/admin_login.html')

def adminLogout(request):
    del request.session['admin_user']
    return redirect('admin_login')


def adminAbout(request):
    about_details = AboutPage.objects.all()
    data = {"aboutDetails": about_details}
    return render(request, 'admin/admin_about.html', data)

def updateAbout(request, id):
    if request.method == 'POST':
        aboutText = request.POST['text']
        about_obj = AboutPage.objects.get(id = id)
        about_obj.about = aboutText
        about_obj.save()
    return redirect('admin_about')

def adminContact(request):
    contact_details = ContactPage.objects.all()
    data = {"contactDetails": contact_details} 
    return render(request, 'admin/admin_contact.html', data)

def updateContact(request, id):
    if request.method == 'POST':
        contactAddress = request.POST['address']
        contactEmail = request.POST['email']
        contactNumber = request.POST['contact']
        contact_obj = ContactPage.objects.get(id = id)
        contact_obj.address = contactAddress
        contact_obj.email = contactEmail
        contact_obj.contact_num = contactNumber
        contact_obj.save()
    return redirect('admin_contact')


def addStudent(request):
    if request.method == 'POST':
        fullName = request.POST['full_name']
        gender = request.POST['gender']
        contactNum = request.POST['contact_number']
        dob = request.POST['dob']
        standard = request.POST['standard']
        medium = request.POST['medium']
        studentUserName = request.POST['stu_user_name']
        studentPassword = request.POST['stu_pwd']

        add_student = Student(full_name=fullName, gender=gender, contact_num=contactNum,
                              date_of_birth=dob, standard=standard, medium=medium, user_name=studentUserName, 
                              password=studentPassword)
        add_student.save()

    return render(request, 'admin/new_student.html')


def manageStudent(request):
    all_students = Student.objects.all()
    data = {"students": all_students}
    print(all_students, data)
    return render(request, 'admin/manage_students.html', data)

def viewStudent(request, id):
    query = f'''
            select str.id, student_id, test_id, td.total_marks, obtained, full_name, td.standard, td.medium,
            td.subject, td.test_date
            from sms_schema.student_test_results str
            left join sms_schema.main_student ms on ms.id=str.student_id
            left join sms_schema.test_data td on td.id=str.test_id
            where student_id={id} ORDER BY str.id desc'''
    
    df = pd.read_sql_query(query, connection)
    df['percentage'] = (df['obtained'] / df['total_marks'] * 100).round(2)
    # all_tests = StudentTestResults.objects.filter(student_id=id)
    all_tests = df.to_dict('records')
    data = {"students": all_tests,
            "id":id}
    print(all_tests, data, "LLLLLLLll")
    return render(request, 'admin/view_student.html', data)


def manageTest(request):
    all_tests = TestData.objects.all()
    data = {"tests": all_tests}
    # print(all_tests, data)
    return render(request, 'admin/manage_tests.html', data)

    # with connection.cursor() as cursor:
    #     cursor.execute("SELECT id, test_date, subject, standard, medium FROM test_data;")
    #     all_tests = cursor.fetchall()
    #     column_names = [desc[0] for desc in cursor.description]
    #     df = pd.DataFrame(all_tests, columns=column_names)
    #     # df.to_dict('records')
    #     data = {"tests": df.to_dict('records')}
    # print(data)
    # return render(request, 'admin/manage_tests.html', data)

def view_test(request, test_id, standard, medium):
    # med = {'guj':'Gujarati Medium', 'eng':'English Medium'}
    
    test_instance = TestData.objects.get(id=test_id)
    student_list = Student.objects.filter(standard=standard, medium=medium)
    
    context = {
        'test_instance': test_instance,
        'student_list': student_list,
    }

    print(request.POST, 'llllllllll')
    if request.method == 'POST':
        print(request.POST)
        # print(form, '1111111111111')
        # if form.is_valid():
            # print(form, 'kkkkkkkkkkkk')
            # Save each student's marks to the StudentTestResults model
        for student in student_list:
            marks_gained = request.POST.get(f"{student.id}")
            st_obj = StudentTestResults(student_id=student.id, test_id=test_instance.id, obtained=marks_gained)
            try:
                st_obj.save()
            except django.db.utils.IntegrityError as e:
                print(e, "EEEEEERRRRRRRRRRRRRROOOOOOOORRRRRRRRRRR")
                return render(request, 'admin/view_test.html', context)
                
        all_tests = TestData.objects.all()
        data = {"tests": all_tests}
        return render(request, 'admin/manage_tests.html', data)
    else:
        form = StudentTestResultsForm()

    
    return render(request, 'admin/view_test.html', context)


@csrf_protect
def addTest(request):
    if request.method == 'POST':
        standard = request.POST['standard']
        subject = request.POST['subject']
        medium = request.POST['medium']
        test_date = request.POST['test_date']
        chapters = request.POST.getlist('chapters')
        # total_marks = request.POST['total_marks']

        if bool(standard) & bool(medium) & bool(test_date) & bool(chapters):
            total_marks = sum([int(request.POST[f'marks_{i}']) for i in chapters if request.POST[f'marks_{i}']!=''])
            chap_list = {int(i) : int(request.POST[f'marks_{i}']) for i in chapters if request.POST[f'marks_{i}']!=''}
            add_test = TestData(standard=standard, test_date=test_date, 
                                chapters=json.dumps(chap_list), total_marks=total_marks, 
                                medium=medium, subject=subject)
            add_test.save()

    # chapters_data = ChapterMaster.objects.filter(std=request.POST['standard'], medium=request.POST['medium'])
    # subjects = set(chapter.subject for chapter in chapters_data)
    # chapters_by_subject = {subject: [chapter.chapter_name for chapter in chapters_data if chapter.subject == subject] for subject in subjects}
    
    # return render(request, 'add_test.html', {'chapters_by_subject': chapters_by_subject})
    return render(request, 'admin/add_test.html')

def get_chapters(request):
    if request.method == 'GET':
        standard = request.GET.get('standard')
        medium = request.GET.get('medium')
        subject = request.GET.get('subject')

        if standard and medium and subject:
            chapters = ChapterMaster.objects.filter(std=standard, medium=medium, subject=subject).values('chapter_no', 'chapter_name').order_by('chapter_no')
            return JsonResponse({'chapters': list(chapters)})
        else:
            return JsonResponse({'chapters': []})

def updateStudent(request, id):
    if request.method == 'POST':
        student_obj = Student.objects.get(id=id)

        fullName = request.POST['full_name']
        gender = request.POST['gender']
        contactNum = request.POST['contact_number']
        dob = request.POST['dob'] or student_obj.date_of_birth
        course = request.POST['course'] or student_obj.course
        studentUserName = request.POST['stu_user_name']
        studentPassword = request.POST['stu_pwd']

        student_obj.full_name = fullName
        student_obj.gender = gender
        student_obj.contact_num = contactNum
        student_obj.date_of_birth = dob
        student_obj.course = course
        student_obj.user_name = studentUserName
        student_obj.password = studentPassword

        student_obj.save()
    return redirect('manage_students')

def deleteStudent(request, id):
    if 'admin_user' in request.session:
        stu_obj = Student.objects.get(id=id)
        print(stu_obj, "LLLLLLLLLLLL")
        stu_obj.delete()
    return redirect('manage_students')


def deleteTest(request, id):
    if 'admin_user' in request.session:
        test_obj = TestData.objects.get(id=id)
        print(test_obj, "LLLLLLLLLLLL")
        test_obj.delete()
    return redirect('manage_tests')


def addNotice(request):
    if request.method == 'POST':
        noticeTitle = request.POST['notice_title']
        noticeContent = request.POST['notice_content']
        isPublic = request.POST['notice_status']

        add_notice = Notice.objects.create(title=noticeTitle, content=noticeContent, isPublic=isPublic)
        add_notice.save()
    return render(request, "admin/admin_notice.html")


def manageNotices(request):
    all_notices = Notice.objects.all()
    data = {'notices': all_notices}
    return render(request, 'admin/manage_notices.html', data)


def deleteNotice(request, id):
    if 'admin_user' in request.session:
        notice_obj = Notice.objects.get(id=id)
        notice_obj.delete()
    return redirect('manage_notices')

def updateNotice(request, id):
    if request.method == 'POST':
        title = request.POST['title']
        content = request.POST['content']
        status = request.POST['status']

        notice_obj = Notice.objects.get(id=id)
        notice_obj.title = title
        notice_obj.content = content
        notice_obj.isPublic = status

        notice_obj.save()
    return redirect('manage_notices')


def addTeacher(request):
    if request.method == 'POST':
        full_name = request.POST['full_name']
        gender = request.POST['gender']
        email = request.POST['email']
        contact_num = request.POST['contact_number']
        qualification = request.POST['qualification']

        add_teacher = Teacher.objects.create(full_name=full_name, gender=gender, email=email,contact_num=contact_num, qualification=qualification)
        add_teacher.save()
    return render(request, 'admin/add_teacher.html')

def manageTeachers(request):
    all_teachers = Teacher.objects.all()
    data = {"teachers": all_teachers}
    return render(request, 'admin/manage_teachers.html', data)

def deleteTeacher(request, id):
    teacher_obj = Teacher.objects.get(id=id)
    teacher_obj.delete()
    return redirect('manage_teachers')

def studentLogin(request):
    if 'student_user' not in request.session:
        if request.method == "POST":
            user_name = request.POST['userName']
            student_pwd = request.POST['stuPwd']

            stu_exists = Student.objects.filter(user_name=user_name, password=student_pwd).exists()
            if stu_exists:
                request.session['student_user'] = user_name
                return redirect('student_dashboard')

        return render(request, 'student/student_login.html')
    else:
        return redirect('student_dashboard')



def studentDashboard(request):
    if 'student_user' in request.session:
        student_in_session = Student.objects.get(user_name=request.session['student_user'])
        data  = {"student": student_in_session}
        return render(request, 'student/student_dashboard.html', data)
    else:
        return redirect('student_login')


def studentLogout(request):
    del request.session['student_user']
    return redirect('student_login')


def updateFaculty(request, id):
    if request.method == 'POST':
        full_name = request.POST['full_name']
        email = request.POST['email']
        contactNumber = request.POST['contact_number']
        gender = request.POST['gender']
        qualification = request.POST['qualification']

        teacher_obj = Teacher.objects.get(id=id)
        teacher_obj.full_name = full_name
        teacher_obj.email = email
        teacher_obj.contact_num = contactNumber
        teacher_obj.gender = gender
        teacher_obj.qualification = qualification
        teacher_obj.save()
    return redirect('manage_teachers')


def viewNotices(request):
    if 'student_user' in request.session:
        student_notice = Notice.objects.filter(isPublic = False)
        data = {"notices": student_notice}
        return render(request, 'student/view_notices.html', data)
    else:
        return redirect('student_login')

def studentSettings(request):
    if 'student_user' in request.session:
        student_obj = Student.objects.get(user_name = request.session['student_user'])
        data = {'student': student_obj}
        if request.method == 'POST':
            currentPwd = request.POST['current_pwd']
            new_pwd = request.POST['new_pwd']
            student_obj.password  =new_pwd
            student_obj.save() 
            return redirect('student_dashboard')      
        return render(request, "student/student_settings.html", data)
    else:
        return redirect('student_login')