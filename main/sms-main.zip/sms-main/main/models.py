from django.db import models
from django.contrib.postgres.fields import ArrayField


# Create your models here.
class AboutPage(models.Model):
    about = models.TextField()

    def __str__(self):
        return self.about

class ContactPage(models.Model):
    address = models.TextField()
    contact_num = models.IntegerField()
    email = models.EmailField()

    def __str__(self):
        return self.address


class Student(models.Model):
    full_name = models.CharField(max_length=100)
    father_name = models.CharField(max_length=100)
    mother_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=50)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    email = models.CharField(max_length=254)
    contact_num = models.CharField(max_length=10)
    date_of_birth = models.DateField()
    medium = models.CharField(max_length=50)
    id = models.BigAutoField(primary_key=True)
    user_name = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    batch = models.IntegerField(blank=True, null=True)
    standard = models.IntegerField(blank=True, null=True)
    is_active = models.BooleanField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'main_student'
    

class TestData(models.Model):
    id = models.BigAutoField(primary_key=True)
    test_date = models.DateField()
    chapters = models.JSONField(default=dict)
    total_marks = models.IntegerField()
    standard = models.IntegerField()
    medium = models.TextField()
    subject = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'test_data'

class Notice(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    isPublic = models.BooleanField(default=False)

    def __str__(self):
        return self.title


class Teacher(models.Model):
    full_name = models.CharField(max_length=100)
    gender = models.CharField(max_length=50)
    email = models.EmailField()
    contact_num = models.CharField(max_length=20)
    qualification = models.TextField()

    def __str__(self):
        return self.full_name


class ChapterMaster(models.Model):
    id = models.IntegerField(primary_key=True)
    chapter_name = models.TextField(blank=True, null=True)
    subject = models.TextField(blank=True, null=True)
    medium = models.TextField(blank=True, null=True)
    chapter_no = models.IntegerField(blank=True, null=True)
    std = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'chapter_master'


class StudentTestResults(models.Model):
    student_id = models.BigIntegerField()
    test_id = models.BigIntegerField()
    total_marks = models.IntegerField(blank=True, null=True)
    obtained = models.IntegerField(blank=True, null=True)
    batch = models.IntegerField(blank=True, null=True)
    created_ts = models.TimeField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'student_test_results'
        unique_together = ('student_id', 'test_id')